package com.intervaltimer.studio;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    private final BroadcastReceiver actionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            final String cmd = intent.getStringExtra("TIMER_CMD");
            if (cmd == null || webView == null) return;
            webView.post(new Runnable() {
                @Override
                public void run() {
                    webView.evaluateJavascript(
                        "if (window.handleAndroidNotificationAction) window.handleAndroidNotificationAction('" + cmd + "');",
                        null
                    );
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidTimerBridge(this), "AndroidTimerBridge");

        IntentFilter filter = new IntentFilter("com.intervaltimer.studio.ACTION_CMD");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(actionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(actionReceiver, filter);
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void cancelAndStopNotificationService() {
        try {
            Intent stopIntent = new Intent(this, TimerForegroundService.class);
            stopService(stopIntent);
            android.app.NotificationManager mgr = (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (mgr != null) {
                mgr.cancelAll();
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        cancelAndStopNotificationService();
        try {
            unregisterReceiver(actionReceiver);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class AndroidTimerBridge {
        private final Context ctx;
        private final SharedPreferences prefs;

        public AndroidTimerBridge(Context context) {
            this.ctx = context;
            this.prefs = context.getSharedPreferences("IntervalTimerDiskPrefs", Context.MODE_PRIVATE);
        }

        @JavascriptInterface
        public void saveStorage(String key, String value) {
            prefs.edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public String loadStorage(String key) {
            String v = prefs.getString(key, "");
            return v != null ? v : "";
        }

        @JavascriptInterface
        public void updateTimerNotification(String jsonPayload) {
            Intent serviceIntent = new Intent(ctx, TimerForegroundService.class);
            serviceIntent.putExtra("PAYLOAD_JSON", jsonPayload);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(serviceIntent);
            } else {
                ctx.startService(serviceIntent);
            }
        }

        @JavascriptInterface
        public void stopTimerNotification() {
            cancelAndStopNotificationService();
        }

        @JavascriptInterface
        public void setImmersiveFullscreen(final boolean enable) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        android.view.View decorView = getWindow().getDecorView();
                        if (enable) {
                            decorView.setSystemUiVisibility(
                                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            );
                        } else {
                            decorView.setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
                        }
                    } catch (Exception ignored) {}
                }
            });
        }
    }
}
