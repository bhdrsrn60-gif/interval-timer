package com.intervaltimer.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import org.json.JSONObject;

public class TimerForegroundService extends Service {
    public static final String CHANNEL_ID = "interval_timer_live_channel";
    public static final int NOTIF_ID = 4020;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    private void stopServiceAndClearNotification() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
            NotificationManager mgr = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (mgr != null) {
                mgr.cancel(NOTIF_ID);
                mgr.cancelAll();
            }
        } catch (Exception ignored) {}
        stopSelf();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopServiceAndClearNotification();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        stopServiceAndClearNotification();
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String actionCmd = intent.getStringExtra("DIRECT_CMD");
            if (actionCmd != null && !actionCmd.isEmpty()) {
                Intent broadcast = new Intent("com.intervaltimer.studio.ACTION_CMD");
                broadcast.setPackage(getPackageName());
                broadcast.putExtra("TIMER_CMD", actionCmd);
                sendBroadcast(broadcast);
                if ("dismiss".equals(actionCmd) || "reset".equals(actionCmd)) {
                    stopServiceAndClearNotification();
                }
                return START_NOT_STICKY;
            }
        }

        String rawJson = intent != null ? intent.getStringExtra("PAYLOAD_JSON") : "{}";
        if (rawJson == null) rawJson = "{}";

        String status = "running";
        String title = "0:40 • Yüksek Yoğunluk";
        String subtitle = "ÇALIŞMA (1/8)";
        String nextText = "Sıradaki: Dinlenme";
        String primaryCmd = "pause";
        String primaryLabel = "Duraklat";
        int progress = 0;

        try {
            JSONObject obj = new JSONObject(rawJson);
            status = obj.optString("status", "running");
            if ("idle".equals(status)) {
                stopServiceAndClearNotification();
                return START_NOT_STICKY;
            }
            title = obj.optString("title", title);
            subtitle = obj.optString("subtitle", subtitle);
            nextText = obj.optString("nextText", nextText);
            primaryCmd = obj.optString("primaryActionCommand", "pause");
            primaryLabel = "pause".equals(primaryCmd) ? "Duraklat" : "Devam Et";
            double ratio = obj.optDouble("progressRatio", 0.0);
            progress = Math.max(0, Math.min(100, (int) Math.round(ratio * 100.0)));
        } catch (Exception ignored) {}

        Notification notification = buildOngoingNotification(
            title,
            subtitle + " • " + nextText,
            primaryLabel,
            primaryCmd,
            progress,
            "running".equals(status)
        );
        startForeground(NOTIF_ID, notification);
        return START_NOT_STICKY;
    }

    private PendingIntent actionPendingIntent(String cmd, int reqCode) {
        Intent intent = new Intent(this, TimerForegroundService.class);
        intent.putExtra("DIRECT_CMD", cmd);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getService(this, reqCode, intent, flags);
    }

    private Notification buildOngoingNotification(
        String title,
        String body,
        String primaryLabel,
        String primaryCmd,
        int progress,
        boolean isRunning
    ) {
        Intent openAppIntent = new Intent(this, MainActivity.class);
        int openFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            openFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentPending = PendingIntent.getActivity(this, 0, openAppIntent, openFlags);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(contentPending)
            .setOngoing(isRunning)
            .setAutoCancel(!isRunning)
            .setDeleteIntent(actionPendingIntent("dismiss", 5))
            .setOnlyAlertOnce(true)
            .setProgress(100, progress, false)
            .addAction(android.R.drawable.ic_media_pause, primaryLabel, actionPendingIntent(primaryCmd, 2))
            .addAction(android.R.drawable.ic_media_next, "Sonraki", actionPendingIntent("next", 3))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Kapat", actionPendingIntent("dismiss", 4))
            .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "IntervalTimer Canlı Sayaç",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Üst bildirim çubuğunda canlı süreyi ve kontrol tuşlarını gösterir");
            channel.setShowBadge(false);
            NotificationManager mgr = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (mgr != null) {
                mgr.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
