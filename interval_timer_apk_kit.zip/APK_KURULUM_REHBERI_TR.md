# Sıfırdan GitHub ile Ücretsiz Android APK Yapma Rehberi (Adım Adım)

Daha önce hiç GitHub kullanmamış olsanız bile bilgisayarınıza hiçbir program kurmadan **3 dakikada** kendi `.apk` dosyanızı üretebilirsiniz.

## Adım 1: İndirdiğiniz ZIP Dosyasını Klasöre Çıkarın
1. İndirdiğiniz **`interval_timer_apk_kit.zip`** dosyasına sağ tıklayın ve **"Tümünü Ayıkla" (Klasöre Çıkar)** seçeneğine tıklayın.
2. Klasörün içinde şu dosyaların olduğunu göreceksiniz:
   - `.github` klasörü (veya `GITHUB_WORKFLOW_KODU.yml`)
   - `android-native-project` klasörü
   - `www` klasörü ve `interval_timer_app.html`

## Adım 2: GitHub'da Yeni Bir Depo (Repository) Açın
1. [GitHub.com](https://github.com/) adresine girin ve ücretsiz giriş yapın (hesabınız yoksa **Sign Up** ile 1 dakikada açabilirsiniz).
2. Sağ üst köşedeki **`+`** (Artı) işaretine tıklayıp **"New repository"** seçeneğine tıklayın.
3. **Repository name** kutusuna `interval-timer` yazın.
4. Alt kısımdan **"Public"** seçeneğini işaretleyin (Ücretsiz sınırsız APK derlemesi için Public seçilmelidir).
5. En alttaki yeşil **"Create repository"** butonuna tıklayın.

## Adım 3: Dosyaları Sürükleyip Bırakın
1. Açılan sayfada **"uploading an existing file"** yazısına tıklayın.
2. Bilgisayarınızda ZIP'ten çıkardığınız klasörün **içine** girin, tüm dosya ve klasörleri (`CTRL + A` ile) seçip GitHub sayfasındaki kutunun içine **sürükleyip bırakın**.
   - *İpucu:* Hatta uğraşmak istemezseniz doğrudan **`interval_timer_apk_kit.zip`** dosyasını ve `.github` klasörünü sürükleyip bırakmanız bile yeterlidir; sistem ZIP'i kendi içinde otomatik açacak şekilde ayarlanmıştır!
3. Dosyalar yüklendikten sonra sayfanın en altındaki yeşil **"Commit changes"** butonuna basın.

## Adım 4: APK'yı Üretin ve Telefonunuza İndirin
1. Üst menüdeki **"Actions"** (Oynat ikonu) sekmesine tıklayın.
   - *(Eğer `.github` klasörü gizli kaldığı için Actions ekranında işlem görmezseniz: **"set up a workflow yourself"** yazısına tıklayın, klasördeki `GITHUB_WORKFLOW_KODU.yml` dosyasının içindeki yazıları kopyalayıp oraya yapıştırın ve sağ üstten **Commit changes** butonuna basın.)*
2. **"Android APK Olustur"** işleminin yanında sarı bir dönen simge göreceksiniz. Yaklaşık **1 - 1.5 dakika** sonra bu simge **yeşil tik (✓)** olacak.
3. Yeşil tik olan **"Android APK Olustur"** başlığına tıklayın.
4. Sayfanın en altındaki **Artifacts** başlığı altında bulunan **`IntervalTimer-Android-APK`** paketine tıklayarak indirin.
5. İnen ZIP'in içindeki **`IntervalTimer-TR.apk`** dosyasını WhatsApp, Telegram veya Google Drive ile telefonunuza gönderip kurun!
